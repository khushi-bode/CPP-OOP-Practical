Practical 5 execution outputs

Output_1.png: Program 1 - Function Types (this pointer, inline function, static members).
Output_2.png: Program 2 - Friend Class.

The programs were compiled and executed with g++ in this environment. These are terminal-style captures of the actual program output, not screenshots of the Dev-C++ application.
